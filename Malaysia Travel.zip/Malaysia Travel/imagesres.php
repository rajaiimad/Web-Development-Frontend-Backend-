<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="./imagesres.css">
    <script type="module" src="./imagesres.js"></script>
</head>
<body>
    <ul class='slider'>
        <li class='item' style="background-image: url(./images/china.avif)">
          <div class='content'>
            <h2 class='title'>"Chinese Temples"</h2>
            <p class='description'> Explore the captivating beauty of Chinese temples in Malaysia, where rich history meets stunning architecture, offering travelers an unforgettable journey through tradition and spirituality.  </p>
            <a href="book.php"><button>Read More</button></a>
          </div>
        </li>
        <li class='item' style="background-image: url(./images/klcc.avif)">
          <div class='content'>
            <h2 class='title'>"Kuala Lumpur"</h2>
            <p class='description'> Experience the dynamic fusion of culture, cuisine, and modernity in Kuala Lumpur, a vibrant metropolis where towering skyscrapers meet bustling street markets, offering travelers an unforgettable adventure in the heart of Malaysia.</p>
            <button>Read More</button>
          </div>
        </li>
        <li class='item' style="background-image: url(./images/beach.avif)">
          <div class='content'>
            <h2 class='title'>"Lanagkawi"</h2>
            <p class='description'> Indulge in the allure of Langkawi, Malaysia's gem nestled in the Andaman Sea, where sun-kissed beaches, emerald rainforests, and intriguing legends converge to offer travelers an enchanting tropical haven filled with natural wonders and thrilling experiences.</p>
            <button>Read More</button>
          </div>
        </li>
        <li class='item' style="background-image: url(./images/batucaves1.avif)">
          <div class='content'>
            <h2 class='title'>"Batu Caves"</h2>
            <p class='description'>
            Unveil the majestic wonder of Batu Caves in Malaysia, where ancient limestone formations tower above vibrant Hindu shrines, inviting adventurers to embark on a mystical journey into one of the country's most iconic and spiritually enriching destinations.
            </p>
            <button>Read More</button>
          </div>
        </li>
        <li class='item' style="background-image: url(./images/Merdeka.avif)">
          <div class='content'>
            <h2 class='title'>"Merdeka street"</h2>
            <p class='description'>
            Experience the vibrant pulse of Malaysia on Merdeka Street, where history, culture, and modernity converge in a kaleidoscope of sights, sounds, and flavors, offering travelers an immersive journey through the heart and soul of Kuala Lumpur.
            </p>
            <button>Read More</button>
          </div>
        </li>
        <li class='item' style="background-image: url(./images/kl.avif)">
          <div class='content'>
            <h2 class='title'>"kuala lumpur"</h2>
            <p class='description'> Discover the epitome of elegance and modernity at KLCC in Malaysia, where the iconic Petronas Twin Towers reign supreme, offering visitors a breathtaking skyline view, world-class shopping, and unforgettable culinary experiences in the heart of Kuala Lumpur.  </p>
            <button>Read More</button>
          </div>
        </li>
      </ul>
      <nav class='nav'>
        <ion-icon class='btn prev' name="arrow-back-outline"></ion-icon>
        <ion-icon class='btn next' name="arrow-forward-outline"></ion-icon>
      </nav>
    </main>
    <section class="home-offer">
   <div class="content">
      <h3>upto 50% off</h3>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Iure tempora assumenda, debitis aliquid nesciunt maiores quas! Magni cumque quaerat saepe!</p>
      <a href="book.php" class="btn">book now</a>
   </div>
</section>
  
    
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
</html>