<?php

   $db_name = 'food-order';
   $db_user_name = 'root';
   $db_user_pass = 'root';

   $conn = new PDO("mysql:host=localhost;port=3306;dbname=rajai-test-db","root","root");

   function create_unique_id(){
      $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      $charactersLength = strlen($characters);
      $randomString = '';
      for ($i = 0; $i < 20; $i++) {
          $randomString .= $characters[mt_rand(0, $charactersLength - 1)];
      }
      return $randomString;
  }

?>