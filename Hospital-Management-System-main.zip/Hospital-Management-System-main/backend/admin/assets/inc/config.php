<?php
$dbuser="root";
$dbpass="database-password";
$host="localhost";
$db="database-name";
$mysqli=new mysqli($host,$dbuser, $dbpass, $db);
?>
