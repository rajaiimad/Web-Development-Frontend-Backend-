<?php
$dbuser="root";
$dbpass="root";
$host="localhost";
$db="hospital-management";
$mysqli=new mysqli($host,$dbuser, $dbpass, $db);
?>